import React from "react";
import Image from "./Image";

export default {title: 'Image'}

export const simple = () => <Image>simple Image tag</Image>