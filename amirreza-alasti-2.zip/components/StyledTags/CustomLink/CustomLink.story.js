import React from "react";
import CustomLink from "./CustomLink";

export default { title: 'CustomLink' }

export const simple = () => <CustomLink> custom link </CustomLink>