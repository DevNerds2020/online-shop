import React from "react";
import H1 from "./H1";

export default {title: 'H1'}

export const simple = () => <H1>simple h1 tag</H1>