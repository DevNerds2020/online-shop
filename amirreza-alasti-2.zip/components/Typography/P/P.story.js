import React from "react";
import P from "./P";

export default {title: 'P'}

export const simple = () => <P>simple P tag</P>