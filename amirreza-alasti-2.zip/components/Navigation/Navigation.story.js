import React from "react";
import Navigation from "./Navigation";

export default {title: 'Navigation'}

export const simple = () => <Navigation>simple Navigation</Navigation>