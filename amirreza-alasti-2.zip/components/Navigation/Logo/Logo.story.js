import React from "react";
import Logo from "./Logo";

export default {title: 'Logo'}

export const simple = () => <Logo>simple Logo</Logo>