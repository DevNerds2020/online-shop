import React from "react";
import Container from "./Container";

export default {title: 'Container'}

export const simple = () => <Container>simple Product Container</Container>