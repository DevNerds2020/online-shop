import React from "react";
import Product from "./Product";

export default {title: 'Product'}

export const simple = () => <Product>simple Product</Product>