import React from "react";
import ProductsList from "./ProductsList";

export default { title: 'ProductsList' }

export const simple = () => <ProductsList>simple ProductsList</ProductsList>

