import React from "react";
import ContactCard from "./ContactCard";

export default {title: 'ContactCard'}

export const simple = () => <ContactCard>simple ContactCard</ContactCard>