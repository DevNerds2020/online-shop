import React from 'react'
import Layout from '../../components/Layout/Layout'

const about = () => {
  return (
    <Layout>مگابیز شاپ بزرگترین مرکز فروش لوازم جانبی گوشی </Layout>
  )
}

export default about