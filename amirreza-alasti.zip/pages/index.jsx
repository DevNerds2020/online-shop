import Head from 'next/head'
import Image from 'next/image'
import Layout from '../components/Layout/Layout'
import Navigation from '../components/Navigation/Navigation'
export default function Home() {
  return (
    <>
      <Layout>
        
      </Layout>
    </>
  )
}
