import React from 'react'
import ContactCard from '../../components/ContactCard/ContactCard'
import Layout from '../../components/Layout/Layout'

const contact = () => {
  return (
    <Layout>
      <ContactCard />
    </Layout>
  )
}

export default contact