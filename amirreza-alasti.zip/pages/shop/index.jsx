import React from 'react'
import Layout from '../../components/Layout/Layout'
import ProductsList from '../../components/ProductsList/ProductsList'
const shop = () => {
  return (
    <Layout>
      <ProductsList />
    </Layout>
  )
}

export default shop