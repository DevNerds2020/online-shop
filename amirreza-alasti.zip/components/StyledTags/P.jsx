import React from 'react'

const P = ({ children }) => {
  return (
    <div>{children}</div>
  )
}

export default P